import Config

config :bot_army_runtime, :auto_start_services, true

nats_host = System.get_env("NATS_HOST", "localhost")

nats_port =
  if config_env() == :test do
    4223
  else
    String.to_integer(System.get_env("NATS_PORT", "4222"))
  end

config :bot_army_runtime, :nats,
  servers: [{nats_host, nats_port}],
  ping_interval: 5000,
  max_reconnect_attempts: 3,
  reconnect_delay_ms: 100

config :bot_army_rpg, BotArmyRpg.Repo,
  database:
    System.get_env("BOT_ARMY_RPG_DB_NAME") || System.get_env("DATABASE_NAME") || "ergon_rpg",
  hostname:
    System.get_env("BOT_ARMY_RPG_DB_HOST") || System.get_env("DATABASE_HOST") || "localhost",
  port:
    String.to_integer(
      System.get_env("BOT_ARMY_RPG_DB_PORT") || System.get_env("DATABASE_PORT") || "30003"
    ),
  username:
    System.get_env("BOT_ARMY_RPG_DB_USER") || System.get_env("DATABASE_USER") || "postgres",
  password:
    System.get_env("BOT_ARMY_RPG_DB_PASSWORD") || System.get_env("DATABASE_PASSWORD") ||
      "postgres",
  pool_size: 3,
  ssl: false
